
#include "Vbtb_test.h"
#include "btb_model.h"
#include <random>
#include <iostream>
#include <stdexcept>
int main(int argc,char**argv) {
 Verilated::commandArgs(argc,argv);Vbtb_test dut;
 std::vector<BtbConfig> configs={{16,2,0,0,1},{16,2,0,0,2},{16,2,0,2,1},{16,2,0,2,2},{16,2,0,3,1},{16,2,0,3,2},{16,2,1,0,1},{16,2,1,0,2},{16,2,1,2,1},{16,2,1,2,2},{16,2,1,3,1},{16,2,1,3,2},{16,2,2,0,1},{16,2,2,0,2},{16,2,2,2,1},{16,2,2,2,2},{16,2,2,3,1},{16,2,2,3,2},{16,4,0,0,1},{16,4,0,0,2},{16,4,0,2,1},{16,4,0,2,2},{16,4,1,0,1},{16,4,1,0,2},{16,4,1,2,1},{16,4,1,2,2},{16,4,2,0,1},{16,4,2,0,2},{16,4,2,2,1},{16,4,2,2,2},{16,2,0,0,0},{32,2,0,0,0},{64,2,0,0,0},{128,2,0,0,0},{16,2,0,1,0},{16,2,0,2,0},{16,2,0,3,0},{32,4,1,2,2},{64,4,2,2,2},{16,2,0,4,1},{16,2,0,4,2},{16,2,1,4,1},{16,2,1,4,2},{16,2,2,4,1},{16,2,2,4,2},{16,4,0,4,1},{16,4,0,4,2},{16,4,1,4,1},{16,4,1,4,2},{16,4,2,4,1},{16,4,2,4,2},{32,4,2,4,2},{64,4,2,4,2},{32,1,2,0,2},{32,1,2,2,2},{32,1,2,4,2},{32,8,1,0,2},{32,8,1,2,2},{32,8,1,4,2},{64,16,2,0,2},{64,16,2,2,2},{64,16,2,4,2}};
 std::vector<BtbModel> models;for(auto c:configs) models.emplace_back(c);
 std::mt19937 rng(0x20261001);uint64_t queries=0,states=0;
 auto check=[&]() {
  for(unsigned n=0;n<models.size();++n) {
   auto &m=models[n];auto *e=m.lookup(dut.lookup_i);
   bool present=(dut.present_o>>n)&1;
   if(present!=bool(e)||(e&&(dut.target_o[n]!=e->target||dut.kind_o[n]!=e->kind))) throw std::runtime_error("query mismatch config "+std::to_string(n));
   ++queries;
   unsigned bits=0;while((1u<<bits)<m.rows.size()) ++bits;
   if(m.config.policy==4) for(unsigned j=0;j<16;++j)
    if(dut.signature_o[n*16+j]!=m.signatures[j]) throw std::runtime_error("signature counter mismatch config "+std::to_string(n));
   for(unsigned s=0;s<m.rows.size();++s) {
    if(dut.next_o[n*64+s]!=m.next[s]) throw std::runtime_error("replacement pointer mismatch");
    for(unsigned w=0;w<m.config.ways;++w) {
     const auto &entry=m.rows[s][w];auto observed=dut.state_o[n*128+s*m.config.ways+w];
     uint64_t expected=(uint64_t(entry.present)<<63)|(uint64_t(entry.kind)<<61)|(uint64_t(entry.pc>>(2+bits))<<32)|entry.target;
     if(bool(observed>>63)!=entry.present || (entry.present&&observed!=expected)) throw std::runtime_error("table state mismatch config "+std::to_string(n));
     if((m.config.policy==2||m.config.policy==4) && dut.reuse_o[n*128+s*m.config.ways+w]!=entry.reuse) throw std::runtime_error("RRPV mismatch config "+std::to_string(n));
     if(m.config.policy==4 && dut.reused_o[n*128+s*m.config.ways+w]!=entry.reused) throw std::runtime_error("reuse outcome mismatch config "+std::to_string(n));
     ++states;
    }
   }
  }
 };
 dut.clk_i=0;dut.rst_ni=0;dut.valid_i=0;dut.invalidate_i=0;dut.eval();dut.clk_i=1;dut.eval();dut.rst_ni=1;
 for(unsigned step=0;step<12000;++step) {
  dut.clk_i=0;
  // Directed conflicts, high-PC tag collisions, repeated targets and randomized full addresses.
  dut.pc_i=step<2000 ? (0x80000000u+((step/3)%80)*64+((step/240)%4)*4) : ((rng()%5)?0x80000000u+(rng()%256)*4:rng()&~3u);
  dut.lookup_i=(step%3==0)?dut.pc_i:((rng()%6)?0x80000000u+(rng()%256)*4:rng()&~3u);
  dut.target_i=rng()&~3u;dut.kind_i=rng()%4;dut.taken_i=rng()%2;
  dut.valid_i=(step%9!=0);dut.invalidate_i=step%257==256;
  dut.eval();check();
  for(auto &m:models) {if(dut.invalidate_i)m.clear();else if(dut.valid_i)m.train(dut.pc_i,dut.target_i,dut.kind_i,dut.taken_i);}
  dut.clk_i=1;dut.eval();check();
  // Query after training without waiting another cycle.
  dut.lookup_i=dut.pc_i;dut.eval();check();
 }
 std::cout<<"PASS BTB configs="<<models.size()<<" queries="<<queries<<" state_entries="<<states<<" seed=0x20261001\n";
}
